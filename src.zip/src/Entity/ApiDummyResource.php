<?php

namespace App\Entity;

use ApiPlatform\Metadata\ApiResource;
use ApiPlatform\Metadata\Post;
use App\Controller\Api\V1\Auth\LoginController;
use App\Controller\Api\V1\Auth\MeController;
use App\Controller\Api\V1\Auth\RefreshTokenController;
use App\Controller\Api\V1\Auth\LogoutController;
use App\Controller\Api\V1\Electricity\VerifyCustomerController;
use App\Controller\Api\V1\Electricity\PurchaseElectricityController;

#[ApiResource(
    operations: [
        new Post(
            uriTemplate: '/v1/auth/login',
            controller: LoginController::class,
            extraProperties: [
                'openapi_context' => [
                    'summary' => 'Login user',
                    'description' => 'Authenticate user and return JWT + API token'
                ]
            ]
        ),
        new Post(
            uriTemplate: '/v1/auth/refresh-token',
            controller: RefreshTokenController::class,
            extraProperties: [
                'openapi_context' => [
                    'summary' => 'Refresh JWT token',
                    'description' => 'Refresh JWT token and API token'
                ]
            ]
        ),

        new Post(
            uriTemplate: '/v1/auth/logout',
            controller: LogoutController::class,
            extraProperties: [
                'openapi_context' => [
                    'summary' => 'Logout user',
                    'description' => 'Invalidate API token and logout'
                ]
            ]
        ),

        new Post(
            uriTemplate: '/v1/electricity/verify-customer',
            controller: VerifyCustomerController::class,
            extraProperties: [
                'openapi_context' => [
                    'summary' => 'Verify electricity customer',
                    'description' => 'Verify customer account before purchase'
                ]
            ]
        ),

        new Post(
            uriTemplate: '/v1/electricity/purchase',
            controller: PurchaseElectricityController::class,
            extraProperties: [
                'openapi_context' => [
                    'summary' => 'Purchase electricity',
                    'description' => 'Purchase electricity for a meter'
                ]
            ]
        ),

        new Post(
            uriTemplate: '/v1/auth/me',
            controller: MeController::class,
            extraProperties: [
                'openapi_context' => [
                    'summary' => 'Get authenticated user info',
                    'description' => 'Return current user profile data'
                ]
            ]
        )
    ]
)]
class ApiDummyResource
{
    // No fields needed, only for Swagger documentation
}
