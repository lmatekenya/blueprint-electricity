<?php

namespace App\Controller\Api\V1\Electricity;

use App\Controller\Api\V1\ElectricityController;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;

class PurchaseElectricityController
{
    public function __construct(private ElectricityController $electricityController) {}

    public function __invoke(Request $request): JsonResponse
    {
        return $this->electricityController->purchaseElectricity($request);
    }
}
