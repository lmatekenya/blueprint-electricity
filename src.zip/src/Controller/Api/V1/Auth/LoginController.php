<?php

namespace App\Controller\Api\V1\Auth;

use App\Controller\Api\V1\AuthController;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;

class LoginController
{
    public function __construct(private AuthController $authController) {}

    public function __invoke(Request $request): JsonResponse
    {
        return $this->authController->login($request);
    }
}
