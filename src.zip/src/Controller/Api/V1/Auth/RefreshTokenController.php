<?php

namespace App\Controller\Api\V1\Auth;

use App\Controller\Api\V1\AuthController;
use Symfony\Component\HttpFoundation\JsonResponse;

class RefreshTokenController
{
    public function __construct(private AuthController $authController) {}

    public function __invoke(): JsonResponse
    {
        return $this->authController->refreshToken();
    }
}
